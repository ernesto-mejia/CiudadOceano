document.addEventListener('DOMContentLoaded', function() {
    var btn_gallery_1 = document.getElementById('btn_product_file_image_1');
    var input_file_1 = document.getElementById('product_file_image_1');
    if (btn_gallery_1) {
        btn_gallery_1.addEventListener('click', function(e) {
            e.preventDefault();
            input_file_1.click();
        });
    }

});

function Ngallery00(e) {
    var input_file_1 = document.getElementById('product_file_image_1');
    input_file_1.addEventListener('change', function() {
        document.getElementById('form_product_gallery_1').submit();
    });
}



document.addEventListener('DOMContentLoaded', function() {
    var btn_gallery_2 = document.getElementById('btn_product_file_image_2');
    var input_file_2 = document.getElementById('product_file_image_2');
    if (btn_gallery_2) {
        btn_gallery_2.addEventListener('click', function(e) {
            e.preventDefault();
            input_file_2.click();
        });
    }

});

function Ngallery01(e) {
    var input_file_2 = document.getElementById('product_file_image_2');
    input_file_2.addEventListener('change', function() {
        document.getElementById('form_product_gallery_2').submit();
    });
}

//3

document.addEventListener('DOMContentLoaded', function() {
    var btn_gallery_3 = document.getElementById('btn_product_file_image_3');
    var input_file_3 = document.getElementById('product_file_image_3');
    if (btn_gallery_3) {
        btn_gallery_3.addEventListener('click', function(e) {
            e.preventDefault();
            input_file_3.click();
        });
    }

});

function Ngallery02(e) {
    var input_file_3 = document.getElementById('product_file_image_3');
    input_file_3.addEventListener('change', function() {
        document.getElementById('form_product_gallery_3').submit();
    });
}

//4

document.addEventListener('DOMContentLoaded', function() {
    var btn_gallery_4 = document.getElementById('btn_product_file_image_4');
    var input_file_4 = document.getElementById('product_file_image_4');
    if (btn_gallery_4) {
        btn_gallery_4.addEventListener('click', function(e) {
            e.preventDefault();
            input_file_4.click();
        });
    }

});

function Ngallery03(e) {
    var input_file_4 = document.getElementById('product_file_image_4');
    input_file_4.addEventListener('change', function() {
        document.getElementById('form_product_gallery_4').submit();
    });
}

//5
document.addEventListener('DOMContentLoaded', function() {
    var btn_gallery_5 = document.getElementById('btn_product_file_image_5');
    var input_file_5 = document.getElementById('product_file_image_5');
    if (btn_gallery_5) {
        btn_gallery_5.addEventListener('click', function(e) {
            e.preventDefault();
            input_file_5.click();
        });
    }

});

function Ngallery04(e) {
    var input_file_5 = document.getElementById('product_file_image_5');
    input_file_5.addEventListener('change', function() {
        document.getElementById('form_product_gallery_5').submit();
    });
}
